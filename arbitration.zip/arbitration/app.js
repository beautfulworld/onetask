// app.js
App({
  onLaunch() {


    let system = wx.getSystemInfoSync();
    this.globalData.statusBarHeight = system['statusBarHeight'];
    //获取胶囊信息
    let menu = wx.getMenuButtonBoundingClientRect();
    this.globalData.menu = menu;
    this.globalData.titleH = (menu.top - system.statusBarHeight) * 2 + menu.height;
  },
  globalData: {
    userInfo: null
  },
})
