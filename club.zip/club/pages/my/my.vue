<template>
	<view>
		<view class="back">
			<view class="u-p-30 colf u-font-36 u-text-center">
				我的
			</view>
			<view class="box" @click="navTo()">
				未登录
			</view>
		</view>
		<view class="container">
			<view class="dis_b" @click="navTo()">
				<view class="dis u-p-t-30 u-p-b-30">
					<image style="width: 30rpx;height: 30rpx;" src="../../static/img/icon.png" mode=""></image>
					<view class="u-font-30 u-m-l-20 col3">
						个人资料
					</view>
				</view>
					<u-icon name="arrow-right" color="#CCCCCC"></u-icon>
			</view>
			<view class="dis_b" @click="navTo()">
				<view class="dis u-p-t-30 u-p-b-30">
					<image style="width: 30rpx;height: 30rpx;" src="../../static/img/icon2.png" mode=""></image>
					<view class="u-font-30 u-m-l-20 col3">
						留言记录
					</view>
				</view>
					<u-icon name="arrow-right" color="#CCCCCC"></u-icon>
			</view>
			<view class="dis_b" @click="navTo()">
				<view class="dis u-p-t-30 u-p-b-30">
					<image style="width: 30rpx;height: 30rpx;" src="../../static/img/icon3.png" mode=""></image>
					<view class="u-font-30 u-m-l-20 col3">
						留言记录
					</view>
				</view>
					<u-icon name="arrow-right" color="#CCCCCC"></u-icon>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			navTo(url){
				if(url){
				location.href=url
				}else{
				 uni.showToast({
				 	title:'暂时未开放',
					icon:'none'
				 })
				}
			}
		}
	}
</script>

<style scoped lang="scss">
     .back{
		 background-image: linear-gradient(top,#E43828,white);
		 height: 300rpx;
	 }
	 .box{
		 padding: 44rpx 49rpx;
		 border-radius: 20rpx;
		 background: #ffffff;
		 box-shadow: 0px 0px 18rpx 5rpx rgba(119,119,119,0.10); 
		 margin-left: 32rpx;
		 margin-right: 32rpx;
		 font-size: 32rpx;
	 }
</style>
