<template>
	<view>
		<swiper :indicator-dots="false" style="height: 432rpx;" :autoplay="true" :interval="3000" :duration="1000">
			<swiper-item>
				<view class="swiper-item">
					<image src="../../static/img/swiper.png" style="width: 100%;height: 432rpx;" mode=""></image>
				</view>
			</swiper-item>
		</swiper>
		<view class="dis_b bgc">
			<view class="grid">
				<image src="../../static/img/tip.png" mode="aspectFit"></image>
				<view class="u-font-26 u-m-t-20 col3">
					通知公告
				</view>
			</view>
			<view class="line">
			</view>
			<view class="grid">
				<image src="../../static/img/tip2.png" mode="aspectFit"></image>
				<view class="u-font-26 u-m-t-20 col3">
					人事代理
				</view>
			</view>
			<view class="line">
			</view>
			<view class="grid">
				<image src="../../static/img/tip3.png" mode="aspectFit"></image>
				<view class="u-font-26 u-m-t-20 col3">
					便民留言板
				</view>
			</view>
		</view>
		<view class="container u-m-t-30 u-m-b-50">
			<u-row gutter="20">
				<u-col span="6">
					<view class="chonse" style="background:url(../../static/img/grid1.png);">
						<view class="u-font-30">
							劳动欠薪投诉
						</view>
					</view>
				</u-col>
				<u-col span="6">
					<view class="chonse" style="background:url(../../static/img/grid2.png);">
						<view class="u-font-30">
							劳动人事仲裁
						</view>
					</view>
				</u-col>
				<u-col span="6">
					<view class="chonse" style="background:url(../../static/img/grid3.png);">
						<view class="u-font-30">
							就业创业服务
						</view>
					</view>
				</u-col>
				<u-col span="6">
					<view class="chonse" style="background:url(../../static/img/grid4.png);">
						<view class="u-font-30">
							参保查询
						</view>
					</view>
				</u-col>
				<u-col span="6">
					<view class="chonse" style="background:url(../../static/img/grid5.png);">
						<view class="u-font-30">
							职称/考试
						</view>
					</view>
				</u-col>
				<u-col span="6">
					<view class="chonse" style="background:url(../../static/img/grid6.png);">
						<view class="u-font-30">
							急愁难盼您请说
						</view>
					</view>
				</u-col>
			</u-row>
			<view class="u-font-20 u-text-center col9 u-m-t-60">
				长治市潞州区人力资源和社会保障局/0355XXXXXXXX
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style scoped lang="scss">
    .grid{
		padding: 25rpx 65rpx;
		text-align: center;
		image{
			width: 49rpx;
			height: 59rpx;
		}
	}
	.chonse{
		padding: 30rpx 30rpx;
		display: flex;
		align-items: center;
		height: 150rpx;
		width: 100%;
		margin-top: 20rpx;
		background-size:100% 100% !important;
	}
	.line{
		width: 2rpx;
		height:100rpx;
		background-color: #E8E8E8;
	}
</style>
