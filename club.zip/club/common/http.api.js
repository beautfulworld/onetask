// 如果没有通过拦截器配置域名的话，可以在这里写上完整的URL(加上域名部分)
//获取出租房
// const baseUrl='https://www.changzhifdc.com/jeecg-boot';
const baseUrl='http://192.168.10.179:8081/jeecg-boot';//孙杰

const login = '/sys/agentLogin';
const commonList = '/publicHouse/fcInfo/listAgent'; // 普通房出租出售列表
const commonSaleQueryById = '/api/oldHome/oldHomeDetails'; // 普通房出售详情
const commonRentQueryById = '/api/leaseHome/details'; // 普通房出租详情
const comList = '/businessCheck/fcInfo/listAgent'; // 商品房出租出售列表
const comQueryById = '/businessCheck/fcInfo/queryById'; // 商品房详情 
const houseList = "/sys/dict/getDictItems/fc_house,house_name,id,audit_status%20='1'";
const condition = "/api/newHouse/queryCondition";
const upload = '/sys/common/upload';
const add = '/publicHouse/fcInfo/add'
/* 上传文件 */
const selectCondition = '/api/newHouse/selectCondition';
const businessFcInfoAdd = '/businessCheck/fcInfo/add';
const queryUser = "/sys/user/getCurrentWithMeal";
const userMealList = "/vipSetMealOrder/fcVipSetMealOrder/userMealList";
const UpdateUser = '/api/personalCenter/updateUser';




// 此处第二个参数vm，就是我们在页面使用的this，你可以通过vm获取vuex等操作，更多内容详见uView对拦截器的介绍部分：
// https://uviewui.com/js/http.html#%E4%BD%95%E8%B0%93%E8%AF%B7%E6%B1%82%E6%8B%A6%E6%88%AA%EF%BC%9F
const install = (Vue, vm) => {
	// 此处没有使用传入的params参数
	let getSearch = (params = {}) => vm.$u.get(hotSearchUrl, {
		id: 2
	});

	// 此处使用了传入的params参数，一切自定义即可
	let getInfo = (params = {}) => vm.$u.post(indexUrl, params);

	// 将各个定义的接口名称，统一放进对象挂载到vm.$u.api(因为vm就是this，也即this.$u.api)下
	vm.$u.api = {
		baseUrl,
		login,
		commonList,
		commonSaleQueryById,
		commonRentQueryById,
		comList,
		comQueryById,
		//所有小区名称
		houseList,
		condition,
		upload,
		add,
		selectCondition,
		businessFcInfoAdd,
		queryUser,
		userMealList,
		UpdateUser,
	};
}

export default {
	install
}
