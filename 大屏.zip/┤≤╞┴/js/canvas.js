var courserate = echarts.init(document.getElementById('courserate'));
var option = {
  tooltip: {
    trigger: 'item',
    formatter: "{a} <br/>{b} : {c} ({d}%)"
  },
  legend: {
    orient: 'vertical',
    right: '30',
    y: 'middle',
    textStyle: {
      color: "#fff",
      fontSize: "12px"
    },
    formatter: function (name) {
      var oa = option.series[0].data;
      var num = oa[0].value + oa[1].value + oa[2].value + oa[3].value;
      for (var i = 0; i < option.series[0].data.length; i++) {
        if (name == oa[i].name) {
          return name + ' ' + oa[i].value;
        }
      }
    },
    data: ['一级预警', '二级预警', '三级预警', '特级预警']
  },
  series: [
    {
      name: 'FK',
      type: 'pie',
      radius: '55%',
      color: ['#27c2c1', '#9ccb63', '#fcd85a', '#60c1de', '#0084c8', '#d8514b'],
      center: ['35%', '50%'],
      data: [
        { value: 335, name: '一级预警' },
        { value: 310, name: '二级预警' },
        { value: 234, name: '三级预警' },
        { value: 135, name: '特级预警' },
      ],
      itemStyle: {
        emphasis: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      },
      itemStyle: {
        normal: {
          label: {
            show: true,
            position: 'outside',
            formatter: '{b}'
          }
        },
        labelLine: { show: true }
      }
    }
  ]
};
courserate.setOption(option);


var resArr = [
  { name: '慢病风险', value: 744 },
  { name: '中医体质', value: 620 },
  { name: '抑郁', value: 740 },
  { name: '焦虑', value: 530 },
]

var xunArr = []
var jingArr = []
var dateArr = []
for (var i = 0; i < resArr.length; i++) {
  xunArr.push(resArr[i].value)
  jingArr.push(resArr[i].value)
  dateArr.push(resArr[i].name)
}

var publicNumChart = echarts.init(document.getElementById('publicNumId'));
var option = {
  tooltip: {
    trigger: 'axis'
  },
  /*legend: {
      x: '35%',
      y: '0%',
      data: ['巡察', '警示'],
      textStyle: {
          color: "#fff",
          fontSize: 8
      },
      itemWidth: 10,
      itemHeight: 10,
  },*/
  calculable: true,
  xAxis: [
    {
      type: 'category',
      data: dateArr,
      axisLabel: {
        interval: 0,
        textStyle: {
          fontSize: 12,
          color: '#fff',
        }
      },
      "axisTick": {       //y轴刻度线
        "show": false
      },
      "axisLine": {       //y轴
        "show": false,
      },
    }
  ],
  yAxis: [
    {
      type: 'value',
      scale: true,
      name: '数量',
      nameTextStyle: {
        color: '#fff',
        fontSize: 12
      },
      max: 1000,
      min: 0,
      boundaryGap: [0.2, 0.2],
      "axisTick": {       //y轴刻度线
        "show": false
      },
      "axisLine": {       //y轴
        "show": false,
      },
      axisLabel: {
        textStyle: {
          color: '#fff',
          fontSize: 12
          // opacity: 0.1,
        }
      },
      splitLine: {  //决定是否显示坐标中网格
        show: true,
        lineStyle: {
          color: ['#fff'],
          opacity: 0.5
        }
      },
    },
    {
      type: 'value',
      scale: true,
      show: false,
      // name: "销量额(万元)",
      nameTextStyle: {
        color: '#fff',
      },
      max: 1,
      min: 0,
      boundaryGap: [0.2, 0.2],
      "axisTick": {       //y轴刻度线
        "show": false
      },
      "axisLine": {       //y轴
        "show": false,
      },
      axisLabel: {
        textStyle: {
          color: '#fff',
          // opacity: 0.1,
        }
      },
      splitLine: {  //决定是否显示坐标中网格
        show: true,
        lineStyle: {
          color: ['#fff'],
          opacity: 0.5
        }
      },

    }
  ],
  // color: ['#2E8CFF', '#38EB70'],
  grid: {
    left: '10%',
    right: '1%',
    top: '25%',
    bottom: '15%'
    // containLabel: true
  },
  series: [
    /* {
         animationDuration: 2500,
         barWidth: '20%',
         name: '巡察',
         type: 'bar',
         data: xunArr,
     },*/
    {
      barWidth: '18%',
      name: '数量',
      type: 'bar',
      data: jingArr,
      color: ['#00BAFF', '#56B557', '#ECA444', '#86529D']
    }
  ],
  animationEasing: 'cubicOut'
};
publicNumChart.setOption(option)


var resArr1 = [
  { name: '值班', value: 724 },
  { name: '直播', value: 620 },
]

var xunArr1 = []
var jingArr1 = []
var dateArr1 = []
for (var i = 0; i < resArr1.length; i++) {
  xunArr1.push(resArr1[i].value)
  jingArr1.push(resArr1[i].value)
  dateArr1.push(resArr1[i].name)
}

var publicNumChart1 = echarts.init(document.getElementById('publicNumId1'));
var option = {
  tooltip: {
    trigger: 'axis'
  },
  // legend: {
  //   x: '35%',
  //   y: '0%',
  //   data: ['人数'],
  //   textStyle: {
  //     color: "#fff",
  //     fontSize: 8
  //   },
  //   itemWidth: 10,
  //   itemHeight: 10,
  // },
  calculable: true,
  xAxis: [
    {
      type: 'category',
      data: dateArr1,
      axisLabel: {
        interval: 0,
        textStyle: {
          fontSize: 12,
          color: '#fff',
        }
      },
      "axisTick": {       //y轴刻度线
        "show": false
      },
      "axisLine": {       //y轴
        "show": false,
      },
    }
  ],
  yAxis: [
    {
      type: 'value',
      scale: true,
      name: '人数',
      nameTextStyle: {
        color: '#fff',
        fontSize: 12
      },
      max: 1000,
      min: 0,
      boundaryGap: [0.2, 0.2],
      "axisTick": {       //y轴刻度线
        "show": false
      },
      "axisLine": {       //y轴
        "show": false,
      },
      axisLabel: {
        textStyle: {
          color: '#fff',
          fontSize: 12
          // opacity: 0.1,
        }
      },
      splitLine: {  //决定是否显示坐标中网格
        show: true,
        lineStyle: {
          color: ['#fff'],
          opacity: 0.5
        }
      },
    },
    {
      type: 'value',
      scale: true,
      show: false,
      // name: "销量额(万元)",
      nameTextStyle: {
        color: '#fff',
      },
      max: 1,
      min: 0,
      boundaryGap: [0.2, 0.2],
      "axisTick": {       //y轴刻度线
        "show": false
      },
      "axisLine": {       //y轴
        "show": false,
      },
      axisLabel: {
        textStyle: {
          color: '#fff',
          // opacity: 0.1,
        }
      },
      splitLine: {  //决定是否显示坐标中网格
        show: true,
        lineStyle: {
          color: ['#fff'],
          opacity: 0.5
        }
      },

    }
  ],
  // color: ['#2E8CFF', '#38EB70'],
  grid: {
    left: '20%',
    right: '1%',
    top: '25%',
    bottom: '15%'
    // containLabel: true
  },
  series: [
    /* {
         animationDuration: 2500,
         barWidth: '20%',
         name: '巡察',
         type: 'bar',
         data: xunArr,
     },*/
    {
      barWidth: '18%',
      name: '人数',
      type: 'bar',
      data: jingArr1,
      color: ['#FED48A', '#00BAFF']
    }
  ],
  animationEasing: 'cubicOut'
};
publicNumChart1.setOption(option)




var resArr2 = [
  { name: '值班', value: 4000 },
  { name: '直播', value: 7000 },
]

var xunArr2 = []
var jingArr2 = []
var dateArr2 = []
for (var i = 0; i < resArr2.length; i++) {
  xunArr2.push(resArr2[i].value)
  jingArr2.push(resArr2[i].value)
  dateArr2.push(resArr2[i].name)
}

var publicNumChart2 = echarts.init(document.getElementById('publicNumId2'));
var option = {
  tooltip: {
    trigger: 'axis'
  },
  /*legend: {
      x: '35%',
      y: '0%',
      data: ['巡察', '警示'],
      textStyle: {
          color: "#fff",
          fontSize: 8
      },
      itemWidth: 10,
      itemHeight: 10,
  },*/
  calculable: true,
  xAxis: [
    {
      type: 'category',
      data: dateArr1,
      axisLabel: {
        interval: 0,
        textStyle: {
          fontSize: 12,
          color: '#fff',
        }
      },
      "axisTick": {       //y轴刻度线
        "show": false
      },
      "axisLine": {       //y轴
        "show": false,
      },
    }
  ],
  yAxis: [
    {
      type: 'value',
      scale: true,
      name: '时长',
      nameTextStyle: {
        color: '#fff',
        fontSize: 12
      },
      max: 10000,
      min: 0,
      boundaryGap: [0.2, 0.2],
      "axisTick": {       //y轴刻度线
        "show": false
      },
      "axisLine": {       //y轴
        "show": false,
      },
      axisLabel: {
        textStyle: {
          color: '#fff',
          fontSize: 12
          // opacity: 0.1,
        }
      },
      splitLine: {  //决定是否显示坐标中网格
        show: true,
        lineStyle: {
          color: ['#fff'],
          opacity: 0.5
        }
      },
    },
    {
      type: 'value',
      scale: true,
      show: false,
      // name: "销量额(万元)",
      nameTextStyle: {
        color: '#fff',
      },
      max: 1,
      min: 0,
      boundaryGap: [0.2, 0.2],
      "axisTick": {       //y轴刻度线
        "show": false
      },
      "axisLine": {       //y轴
        "show": false,
      },
      axisLabel: {
        textStyle: {
          color: '#fff',
          // opacity: 0.1,
        }
      },
      splitLine: {  //决定是否显示坐标中网格
        show: true,
        lineStyle: {
          color: ['#fff'],
          opacity: 0.5
        }
      },

    }
  ],
  // color: ['#2E8CFF', '#38EB70'],
  grid: {
    left: '22%',
    right: '1%',
    top: '25%',
    bottom: '15%'
    // containLabel: true
  },
  series: [
    /* {
         animationDuration: 2500,
         barWidth: '20%',
         name: '巡察',
         type: 'bar',
         data: xunArr,
     },*/
    {
      barWidth: '18%',
      name: '时长',
      type: 'bar',
      data: jingArr2,
      color: ['#FED48A', '#00BAFF']
    }
  ],
  animationEasing: 'cubicOut'
};
publicNumChart2.setOption(option)



/*折线图*/

var myChart2 = echarts.init(document.getElementById('main2'));

init_myChart2();

function init_myChart2() {
  var data = {
    "uploadData": [{ "count": 3230 }, { "count": 2986 }, { "count": 392 }, { "count": 1642 }, { "count": 1521 }, { "count": 2573 }
      , { "count": 3132 }, { "count": 147 }, { "count": 3283 }, { "count": 336 }, { "count": 3831 }, { "count": 3633 }],
    "updateData": [{ "count": 3000 }, { "count": 1890 }, { "count": 670 }, { "count": 2659 }, { "count": 1670 }, { "count": 1890 }
      , { "count": 2890 }, { "count": 200 }, { "count": 2501 }, { "count": 1452 }, { "count": 2201 }, { "count": 1177 }],
    "viewData": [{ "count": 1651 }, { "count": 1842 }, { "count": 2223 }, { "count": 2123 }, { "count": 2021 }, { "count": 1812 }
      , { "count": 1928 }, { "count": 1019 }, { "count": 613 }, { "count": 2754 }, { "count": 981 }, { "count": 3001 }]
  };
  var uploadCnt = [];
  var updateCnt = [];

  var viewCnt = [];
  if (data.uploadData != null) {
    for (var i = 0; i < data.uploadData.length; i++) {
      uploadCnt.push(data.uploadData[i].count);
    }
  }
  if (data.updateData != null) {
    for (var i = 0; i < data.updateData.length; i++) {
      updateCnt.push(data.updateData[i].count);
    }
  }

  if (data.viewData != null) {
    for (var i = 0; i < data.viewData.length; i++) {
      viewCnt.push(data.viewData[i].count);
    }
  }
  option = {

    tooltip: {
      trigger: 'axis',
      formatter: function (params, ticket, callback) {
        var res = '';
        for (var i = 0, l = params.length; i < l; i++) {
          res += '' + params[i].seriesName + ' : ' + params[i].value + '<br>';
        }
        return res;
      },
      transitionDuration: 0,
      backgroundColor: 'rgba(83,93,105,0.8)',
      borderColor: '#535b69',
      borderRadius: 8,
      borderWidth: 2,
      padding: [5, 10],
      axisPointer: {
        type: 'line',
        lineStyle: {
          type: 'dashed',
          color: '#fff'
        }
      }
    },
    legend: {
      icon: 'line',
      itemWidth: 8,
      itemHeight: 8,
      itemGap: 10,
      top: '16',
      right: '10',
      data: ['视频时长', '语音时长', '图文数量'],
      textStyle: {
        fontSize: 12,
        color: ['#10F5FF',]
      }
    },
    grid: {
      top: '46',
      left: '12%',
      right: '4%',
      bottom: '20%',
      containLabel: false
    },
    xAxis: [{
      type: 'category',
      boundaryGap: false,
      axisLabel: {
        interval: 0,
        fontSize: 10
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: '#fff',
          opacity: 0.5
        }
      },
      axisTick: {
        show: false
      },
      splitLine: {
        lineStyle: {
          color: '#00FFFF'
        }
      },
      data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
      offset: 10
    }],
    yAxis: [{
      type: 'value',
      axisLine: {
        show: false,
        lineStyle: {
          color: '#fff'
        }
      },
      axisLabel: {
        margin: 10,
        textStyle: {
          fontSize: 12
        }
      },
      splitLine: {
        show: false
      },
      axisTick: {
        show: true
      }
    }],
    series: [{
      name: '视频时长',
      type: 'line',
      smooth: true,
      showSymbol: false,
      lineStyle: {
        normal: {
          width: 0.5
        }
      },
      areaStyle: {
        normal: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
            offset: 0,
            color: 'rgba(137, 189, 27, 0.3)'
          }, {
            offset: 0.8,
            color: 'rgba(137, 189, 27, 0)'
          }], false),
          shadowColor: 'rgba(0, 0, 0, 0.1)',
          shadowBlur: 10
        }
      },
      itemStyle: {
        normal: {
          color: '#BAB8FF'
        }
      },
      data: uploadCnt
    }, {
      name: '语音时长',
      type: 'line',
      smooth: true,
      showSymbol: false,
      lineStyle: {
        normal: {
          width: 0.5
        }
      },
      areaStyle: {
        normal: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
            offset: 0,
            color: 'rgba(219, 50, 51, 0.3)'
          }, {
            offset: 0.8,
            color: 'rgba(219, 50, 51, 0)'
          }], false),
          shadowColor: 'rgba(0, 0, 0, 0.1)',
          shadowBlur: 10
        }
      },
      itemStyle: {
        normal: {
          color: '#FFD200'
        }
      },
      data: viewCnt
    }, {
      name: '图文数量',
      type: 'line',
      smooth: true,
      showSymbol: false,
      lineStyle: {
        normal: {
          width: 0.5
        }
      },
      areaStyle: {
        normal: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
            offset: 0,
            color: 'rgba(0, 136, 212, 0.3)'
          }, {
            offset: 0.8,
            color: 'rgba(0, 136, 212, 0)'
          }], false),
          shadowColor: '#00FFFF',
          shadowBlur: 10
        }
      },
      itemStyle: {
        normal: {
          color: ['#10F5FF']
        }
      },
      data: updateCnt
    }
    ]
  };
  myChart2.setOption(option);

  window.addEventListener("resize", function () {
    courserate.resize();
    publicNumChart.resize();
    publicNumChart1.resize();
    publicNumChart2.resize();
    myChart2.resize();
  });
}

function drawLayer03Right(canvasObj, colorValue, rate, monitor, name, number) {
  var ctx = canvasObj.getContext("2d");

  var circle = {
    x: canvasObj.clientWidth / 2 - 10,    //圆心的x轴坐标值
    y: canvasObj.clientWidth / 2,    //圆心的y轴坐标值
    r: canvasObj.clientWidth / 2 - 22     //圆的半径
  };

  //画扇形
  //ctx.sector(circle.x,circle.y,circle.r,1.5*Math.PI,(1.5+rate*2)*Math.PI);
  //ctx.fillStyle = colorValue;
  //ctx.fill();

  ctx.beginPath();
  ctx.arc(circle.x, circle.y, circle.r, 0, Math.PI * 2)
  ctx.lineWidth = 7;
  ctx.strokeStyle = '#BCEAFF';
  ctx.stroke();
  ctx.closePath();


  ctx.beginPath();
  ctx.arc(circle.x, circle.y, circle.r, 1.5 * Math.PI, (1.5 + rate * 2) * Math.PI)
  ctx.lineWidth = 8;
  ctx.strokeStyle = colorValue;
  ctx.stroke();
  ctx.closePath();

  var shuzhiX = circle.x + circle.r - 10;
  var shuzhiY = circle.y + number;

  ctx.beginPath();
  ctx.lineWidth = 1;
  ctx.lineCap = "butt";
  ctx.moveTo(shuzhiX, shuzhiY);
  ctx.lineTo(shuzhiX + 40, shuzhiY);
  ctx.stroke();

  ctx.fillStyle = 'white';
  ctx.font = '11px Calibri';
  if (name.length >= 4) {
    var text = name.split('');
    var wen1 = "";
    var wen2 = "";
    console.log(text);
    for (let i = 0; i < text.length; i++) {
      if (i < 2) {
        wen1 += text[i];
      } else {
        wen2 += text[i];
      }
    }
    ctx.fillText(wen1, circle.x - (12 * wen1.length) / 2, circle.y - 3);
    ctx.fillText(wen2, circle.x - (12 * wen2.length) / 2, circle.y + 12);
    ctx.fillText(rate * 100 + '%', shuzhiX + 15, shuzhiY - 5);
    ctx.fillText(monitor, shuzhiX + 15, shuzhiY + 15);
  } else {
    ctx.fillText(name, circle.x - (12 * name.length) / 2, circle.y + 5);
    ctx.fillText(rate * 100 + '%', shuzhiX + 12, shuzhiY - 5);
    ctx.fillText(monitor, shuzhiX + 15, shuzhiY + 15);
  }

}

function renderLayer03Right() {
  drawLayer03Right($("#layer03_right_chart01 canvas").get(0), "#FEB300", 0.3, 550 + '人', '血压心率', -20);
  drawLayer03Right($("#layer03_right_chart02 canvas").get(0), "#FF5455", 0.2, 150 + '人', '血糖', -20);
  drawLayer03Right($("#layer03_right_chart03 canvas").get(0), "#56B557", 0.1, 100 + '人', '血尿酸', -20);
  drawLayer03Right($("#layer03_right_chart04 canvas").get(0), "#0030FF", 0.2, 130 + '人', '血脂', -20);
}
renderLayer03Right();
