
var map = [
  { area: "北京", cnt: 30 },
  { area: "山西", cnt: 300 },
  { area: "陕西", cnt: 20 },
  { area: "广西", cnt: 50 },
  { area: "西藏", cnt: 1 },
  { area: "新疆", cnt: 20 },
]


$(function () {
  var worldMapContainer1 = document.getElementById('map_contnet');
  var myChart = echarts.init(worldMapContainer1);
  var option = {
    tooltip: {
      trigger: 'item'
    },
    legend: {
      orient: 'vertical',
      x: 'left',
      y: 'bottom',
      data: [
        '已安装设备'
      ],
      textStyle: {
        color: '#fff'
      }
    },
    visualMap: {
      min: 0,
      max: 2500,
      left: 'right',
      top: 'bottom',
      text: ['高', '低'], // 文本，默认为数值文本
      calculable: true,
      color: ['#0047db', '#f2b600', '#009ab1'],
      textStyle: {
        color: '#00e6ff'
      }
    },
    series: [{
      type: 'map',
      aspectScale: 0.75,
      zoom: 1.2,
      mapType: 'changzhi',
      roam: false,
      label: {
        normal: {
          show: true,//显示省份标签
          textStyle: { color: "#fff" }//省份标签字体颜色
        },
        emphasis: {//对应的鼠标悬浮效果
          show: true,
          textStyle: { color: "#fff" }
        }
      },
      itemStyle: {
        normal: {
          borderWidth: .5,//区域边框宽度
          borderColor: '#009fe8',//区域边框颜色
          areaColor: "#00e6ff",//区域颜色
        },
        emphasis: {
          borderWidth: .5,
          borderColor: '#007afa',
          areaColor: "#009af9",
        }
      },
      data: function () {
        var serie = [];
        for (var i = 0; i < map.length; i++) {
          var item = {
            name: map[i].area,
            value: map[i].cnt
          };
          serie.push(item);
        }
        return serie;
      }()

    }
    ]
  };


  // 使用刚指定的配置项和数据显示图表。
  myChart.setOption(option);
  myChart.on('click', function (params) {//点击事件
    if (params.componentType === 'series') {
    }
  })

  window.addEventListener("resize", function () {
    myChart.resize()
  })
}
)
